function Product(title, description, imageUrl, actualPrice, discountPrice, discount, redirectUrl) {
    this.title = title;
    this.description = description;
    this.imageUrl = imageUrl;
    this.actualPrice = actualPrice;
    this.discountPrice = discountPrice;
    this.discount = discount;
    this.redirectUrl = redirectUrl;

}
var productsList = [];
var casper = require('casper').create();
casper.options.pageSettings.loadImages = false;
casper.start('http://www.amazon.in/s/ref=sr_pg_2?rh=n%3A976392031%2Cn%3A%21976393031%2Cn%3A1375458031%2Cp_76%3A1318482031&page=2&bbn=1375458031&ie=UTF8&qid=1426669276');
casper.then(function () {

    this.echo("site opened");
    this.echo('started scrapping')

});
casper.then(function () {
    this.echo('started evaluting');
    productsList = this.evaluate(function () {
        var tempProducts = [];
        $("[id^=result_]").each(function () {
            var title = $(this).find('div.a-row.a-spacing-none > a > h2').text();
            title = title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replace(/\s+/g, " ");
            var actualPrice = $(this).find('span.a-size-small.a-color-secondary.a-text-strike').text();
            var discountPrice = $(this).find('a > span').text();
            // var description = 'Desc Text';
            // var imageUrl = 'http://google.com/';
            // var redirectUrl = "http://w3schools.com";
            // var discount = '5';
            __utils__.echo(title);
           console.log("hello");
            tempProducts.push({
               "title": title,
                // "actualPrice": actualPrice,
                // "discountPrice": discountPrice,
                // "description": description,
                // "redirectUrl": redirectUrl,
                // "discount": discount
            });
        });
        __utils__.echo(tempProducts.length);
        return tempProducts;
    });
    this.echo("evaluation end");
    this.echo(productsList.length);
    this.echo(productsList);
})


casper.run();

// div>ul>li[data-asin*="B00"]
// "li[id^='result_']"


